"use client";

import { useCallback, useRef, useState } from "react";

import { STREAM_ERROR_MARKER } from "@/lib/constants";

export type StreamStatus = "idle" | "streaming" | "done" | "error";

interface RunOptions {
  /** Called with the full text so far on every chunk. */
  onUpdate?: (text: string) => void;
}

/** Starts a request and resolves with a streaming text `Response`. */
export type StreamRequest = (signal: AbortSignal) => Promise<Response>;

/**
 * Run a streaming text request (see `src/lib/api.ts`) and expose the accumulating response.
 *
 * Handles three kinds of failure: non-2xx JSON errors before streaming starts,
 * in-band errors sent after `STREAM_ERROR_MARKER`, and network failures.
 * Resolves with the final text (or null on error/abort).
 */
export function useTextStream() {
  const [text, setText] = useState("");
  const [status, setStatus] = useState<StreamStatus>("idle");
  const [error, setError] = useState<string | null>(null);
  const controllerRef = useRef<AbortController | null>(null);

  const stop = useCallback(() => {
    controllerRef.current?.abort();
    controllerRef.current = null;
  }, []);

  const reset = useCallback(() => {
    stop();
    setText("");
    setError(null);
    setStatus("idle");
  }, [stop]);

  const run = useCallback(
    async (request: StreamRequest, options: RunOptions = {}): Promise<string | null> => {
      stop();
      const controller = new AbortController();
      controllerRef.current = controller;

      setText("");
      setError(null);
      setStatus("streaming");

      let accumulated = "";
      const fail = (message: string) => {
        setError(message);
        setStatus("error");
        return null;
      };

      try {
        const response = await request(controller.signal);

        if (!response.ok || !response.body) {
          const data = (await response.json().catch(() => null)) as { error?: string } | null;
          return fail(data?.error ?? `Request failed (${response.status}).`);
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder();

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          accumulated += decoder.decode(value, { stream: true });

          // Never show the error marker itself in the output.
          const markerIndex = accumulated.indexOf(STREAM_ERROR_MARKER);
          const visible = markerIndex === -1 ? accumulated : accumulated.slice(0, markerIndex);
          setText(visible);
          options.onUpdate?.(visible);
        }
        accumulated += decoder.decode();

        const markerIndex = accumulated.indexOf(STREAM_ERROR_MARKER);
        if (markerIndex !== -1) {
          const visible = accumulated.slice(0, markerIndex);
          setText(visible);
          return fail(accumulated.slice(markerIndex + STREAM_ERROR_MARKER.length).trim());
        }

        setText(accumulated);
        setStatus("done");
        return accumulated;
      } catch (err) {
        if (controller.signal.aborted) {
          // User cancelled — keep whatever arrived so far.
          setStatus(accumulated ? "done" : "idle");
          return null;
        }
        return fail(
          err instanceof Error && err.message
            ? `Connection problem: ${err.message}`
            : "Connection problem. Please try again.",
        );
      } finally {
        if (controllerRef.current === controller) controllerRef.current = null;
      }
    },
    [stop],
  );

  return { text, status, error, run, stop, reset, setText };
}
