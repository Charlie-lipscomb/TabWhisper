/**
 * Client-side entry points for the three AI operations.
 *
 * - Server mode (default, e.g. Vercel): calls this app's API routes, which hold
 *   the API key in an environment variable.
 * - Static mode (`STATIC_EXPORT=true` builds, e.g. GitHub Pages): there is no
 *   server, so requests go straight from the browser to Anthropic with the
 *   visitor's own API key.
 *
 * Every function returns a standard `Response`, so the UI handles both modes
 * the same way.
 */

import { browserAnalyze, browserAsk, browserExtract } from "./ai/browser";

/** Baked in at build time by next.config.ts. */
export const IS_STATIC = process.env.NEXT_PUBLIC_STATIC_EXPORT === "true";

function postJson(path: string, body: unknown, signal?: AbortSignal): Promise<Response> {
  return fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
    signal,
  });
}

export function requestAnalysis(
  body: { content: string; sourceUrl?: string },
  signal: AbortSignal,
): Promise<Response> {
  return IS_STATIC ? browserAnalyze(body, signal) : postJson("/api/analyze", body, signal);
}

export function requestAnswer(
  body: { content: string; sourceUrl?: string; question: string; history: { question: string; answer: string }[] },
  signal: AbortSignal,
): Promise<Response> {
  return IS_STATIC ? browserAsk(body, signal) : postJson("/api/ask", body, signal);
}

export function requestExtract(url: string): Promise<Response> {
  return IS_STATIC ? browserExtract(url) : postJson("/api/extract", { url });
}
