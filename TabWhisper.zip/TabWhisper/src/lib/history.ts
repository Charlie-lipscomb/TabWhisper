/**
 * Recent analyses, persisted in the browser's localStorage.
 * Nothing is stored on the server.
 */

export interface QATurn {
  question: string;
  answer: string;
}

export interface Analysis {
  id: string;
  createdAt: number;
  title: string;
  /** The text that was analyzed. */
  content: string;
  /** Present when the content was loaded from a URL. */
  sourceUrl?: string;
  /** Raw Markdown returned by the analysis call. */
  result: string;
  qa: QATurn[];
}

const STORAGE_KEY = "tabwhisper:history:v1";
const MAX_ITEMS = 20;

export function loadHistory(): Analysis[] {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    const parsed: unknown = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? (parsed as Analysis[]) : [];
  } catch {
    return [];
  }
}

/** Save the list, dropping the oldest entries if storage is full. */
export function saveHistory(items: Analysis[]): Analysis[] {
  let list = items.slice(0, MAX_ITEMS);
  while (list.length > 0) {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
      return list;
    } catch {
      // Quota exceeded (long articles add up) — drop the oldest and retry.
      list = list.slice(0, -1);
    }
  }
  try {
    window.localStorage.removeItem(STORAGE_KEY);
  } catch {
    // Storage unavailable (e.g. private mode) — history just won't persist.
  }
  return list;
}

/** Insert or replace an analysis, keeping the newest first. */
export function upsertAnalysis(items: Analysis[], analysis: Analysis): Analysis[] {
  return [analysis, ...items.filter((item) => item.id !== analysis.id)];
}

export function createId(): string {
  return typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}
