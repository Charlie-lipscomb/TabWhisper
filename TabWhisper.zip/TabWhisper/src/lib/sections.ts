import { SECTION_HEADINGS } from "./constants";

export type SectionKey = keyof typeof SECTION_HEADINGS;

export type Sections = Record<SectionKey, string>;

const ORDER: SectionKey[] = ["title", "summary", "keyPoints", "actionItems"];

/**
 * Split the streamed Markdown analysis into its sections.
 *
 * Works on partial text too: a section's content is everything between its
 * heading and the next known heading (or the end of the text so far), so each
 * tab fills in live as Claude writes.
 */
export function parseSections(markdown: string): Sections {
  const result: Sections = { title: "", summary: "", keyPoints: "", actionItems: "" };

  // Locate each heading at the start of a line.
  const positions = ORDER.map((key) => {
    const pattern = new RegExp(`^${SECTION_HEADINGS[key]}\\s*$`, "mi");
    const match = pattern.exec(markdown);
    return match ? { key, start: match.index, bodyStart: match.index + match[0].length } : null;
  })
    .filter((entry): entry is NonNullable<typeof entry> => entry !== null)
    .sort((a, b) => a.start - b.start);

  positions.forEach((entry, i) => {
    const end = i + 1 < positions.length ? positions[i + 1].start : markdown.length;
    result[entry.key] = markdown.slice(entry.bodyStart, end).trim();
  });

  // If the model ignored the format entirely, show everything as the summary.
  if (positions.length === 0 && markdown.trim() && !markdown.trimStart().startsWith("#")) {
    result.summary = markdown.trim();
  }

  // Titles are a single line; drop stray Markdown emphasis or quotes.
  result.title = result.title.split("\n")[0].replace(/^[#*_"'\s]+|[*_"'\s]+$/g, "");

  return result;
}
