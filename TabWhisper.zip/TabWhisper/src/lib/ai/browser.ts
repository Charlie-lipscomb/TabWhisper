/**
 * "Bring your own key" mode for static hosting (e.g. GitHub Pages).
 *
 * A static site has no server to keep a secret, so each visitor supplies their
 * own Anthropic API key. It is stored only in this browser's localStorage and
 * sent only to api.anthropic.com — never to the site's host.
 */

import Anthropic from "@anthropic-ai/sdk";

import { prepareAnalyze, prepareAsk } from "./requests";
import {
  type ClaudeOptions,
  DEFAULT_MODEL,
  describeError,
  type Effort,
  fallbackParams,
  parseEffort,
  streamMessage,
  toTextStreamResponse,
} from "./stream";

// ---------------------------------------------------------------------------
// Settings (localStorage + a tiny subscribable store for React)
// ---------------------------------------------------------------------------

export interface BrowserSettings {
  apiKey: string;
  model: string;
  effort: Effort;
}

const SETTINGS_KEY = "tabwhisper:settings:v1";
const DEFAULT_SETTINGS: BrowserSettings = { apiKey: "", model: DEFAULT_MODEL, effort: "medium" };

const listeners = new Set<() => void>();
let cached: BrowserSettings | null = null;

export function getSettings(): BrowserSettings {
  if (cached) return cached;
  try {
    const raw = window.localStorage.getItem(SETTINGS_KEY);
    const parsed = raw ? (JSON.parse(raw) as Partial<BrowserSettings>) : {};
    cached = {
      apiKey: typeof parsed.apiKey === "string" ? parsed.apiKey : "",
      model: typeof parsed.model === "string" && parsed.model ? parsed.model : DEFAULT_MODEL,
      effort: parseEffort(parsed.effort),
    };
  } catch {
    cached = { ...DEFAULT_SETTINGS };
  }
  return cached;
}

/** Server render / pre-hydration snapshot: no key known yet. */
export function getServerSettings(): BrowserSettings {
  return DEFAULT_SETTINGS;
}

export function saveSettings(settings: BrowserSettings): void {
  cached = { ...settings, apiKey: settings.apiKey.trim(), model: settings.model.trim() || DEFAULT_MODEL };
  try {
    window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(cached));
  } catch {
    // Storage unavailable (private mode) — the key still works for this visit.
  }
  listeners.forEach((listener) => listener());
}

export function subscribeSettings(listener: () => void): () => void {
  listeners.add(listener);
  // Keep multiple tabs in sync.
  const onStorage = (event: StorageEvent) => {
    if (event.key === SETTINGS_KEY) {
      cached = null;
      listener();
    }
  };
  window.addEventListener("storage", onStorage);
  return () => {
    listeners.delete(listener);
    window.removeEventListener("storage", onStorage);
  };
}

// ---------------------------------------------------------------------------
// Requests
// ---------------------------------------------------------------------------

const MISSING_KEY_MESSAGE = "Add your Anthropic API key in Settings to get started.";

function getBrowserClient(): { client: Anthropic; options: ClaudeOptions } | null {
  const settings = getSettings();
  if (!settings.apiKey) return null;
  return {
    // Required for direct browser → API calls. Safe here because the key is
    // the visitor's own and never leaves their browser except to Anthropic.
    client: new Anthropic({ apiKey: settings.apiKey, dangerouslyAllowBrowser: true }),
    options: { model: settings.model, effort: settings.effort, fallbacks: true },
  };
}

function missingKey(): Response {
  return Response.json({ error: MISSING_KEY_MESSAGE, code: "missing_key" }, { status: 401 });
}

/** Browser equivalent of POST /api/analyze. */
export async function browserAnalyze(body: unknown, signal: AbortSignal): Promise<Response> {
  const prepared = prepareAnalyze(body);
  if (!prepared.ok) return prepared.response;
  const ctx = getBrowserClient();
  if (!ctx) return missingKey();
  return toTextStreamResponse(streamMessage(ctx.client, ctx.options, prepared.request), signal);
}

/** Browser equivalent of POST /api/ask. */
export async function browserAsk(body: unknown, signal: AbortSignal): Promise<Response> {
  const prepared = prepareAsk(body);
  if (!prepared.ok) return prepared.response;
  const ctx = getBrowserClient();
  if (!ctx) return missingKey();
  return toTextStreamResponse(streamMessage(ctx.client, ctx.options, prepared.request), signal);
}

const FETCH_ERRORS: Record<string, string> = {
  url_not_accessible: "Couldn't load that page. It may be down, private, or blocking automated access.",
  unsupported_content_type: "That URL isn't a web page Claude can read.",
  content_too_large: "That page is too large to load.",
  url_not_allowed: "That site can't be fetched (it may be blocked by your organization's settings).",
  too_many_requests: "Too many requests — please wait a moment and try again.",
};

/**
 * Browser equivalent of POST /api/extract.
 *
 * Browsers can't fetch arbitrary websites (CORS), so this asks Claude to fetch
 * the page with its server-side web fetch tool and returns the page text from
 * the tool result. Requires web fetch to be enabled for your organization in
 * the Claude Console.
 */
export async function browserExtract(rawUrl: string): Promise<Response> {
  const ctx = getBrowserClient();
  if (!ctx) return missingKey();

  let url: URL;
  try {
    url = new URL(rawUrl);
    if (url.protocol !== "http:" && url.protocol !== "https:") throw new Error();
  } catch {
    return Response.json({ error: "That doesn't look like a valid URL." }, { status: 400 });
  }

  try {
    const message = await ctx.client.beta.messages.create({
      model: ctx.options.model,
      max_tokens: 2_048,
      output_config: { effort: "low" },
      tools: [
        {
          type: "web_fetch_20260209",
          name: "web_fetch",
          max_uses: 1,
          // Call the tool directly (no code-execution filtering) so the full page text comes back.
          allowed_callers: ["direct"],
          max_content_tokens: 100_000,
        },
      ],
      messages: [
        {
          role: "user",
          content: `Use the web_fetch tool exactly once to fetch this URL: ${url.toString()}\nAfter it returns, reply with only the word "done". Do not summarize the page.`,
        },
      ],
      ...fallbackParams(ctx.options.fallbacks),
    });

    for (const block of message.content) {
      if (block.type !== "web_fetch_tool_result") continue;
      if (block.content.type === "web_fetch_tool_result_error") {
        const error = FETCH_ERRORS[block.content.error_code] ?? "Couldn't load that page.";
        return Response.json({ error: `${error} Try pasting the text instead.` }, { status: 502 });
      }
      const document = block.content.content;
      if (document.source.type !== "text") {
        return Response.json(
          { error: "That URL is a PDF or binary file — paste its text instead." },
          { status: 415 },
        );
      }
      const content = document.source.data.trim();
      if (content.length < 50) {
        return Response.json(
          { error: "Couldn't find readable content on that page — try pasting the text instead." },
          { status: 422 },
        );
      }
      const finalUrl = block.content.url || url.toString();
      return Response.json({
        title: document.title?.trim() || new URL(finalUrl).hostname,
        content,
        url: finalUrl,
      });
    }

    return Response.json(
      {
        error:
          "Claude didn't fetch the page. Web fetch may be disabled for your organization in the Claude Console — try pasting the text instead.",
      },
      { status: 502 },
    );
  } catch (error) {
    const { message, status } = describeError(error);
    return Response.json({ error: message }, { status });
  }
}
