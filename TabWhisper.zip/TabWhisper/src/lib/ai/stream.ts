/**
 * Claude request helpers shared by the server routes (Vercel / Node hosting)
 * and the browser client (static hosting such as GitHub Pages).
 *
 * Both sides produce a standard `Response` whose body is the streamed Markdown
 * text, so the UI consumes them identically.
 */

import Anthropic from "@anthropic-ai/sdk";

import { STREAM_ERROR_MARKER } from "@/lib/constants";

export const DEFAULT_MODEL = "claude-opus-5-5";

export const EFFORTS = ["low", "medium", "high", "xhigh", "max"] as const;
export type Effort = (typeof EFFORTS)[number];
/** `medium` keeps responses fast while staying thorough. */
export const DEFAULT_EFFORT: Effort = "medium";

export function parseEffort(value: string | null | undefined): Effort {
  return EFFORTS.includes(value as Effort) ? (value as Effort) : DEFAULT_EFFORT;
}

export interface ClaudeOptions {
  model: string;
  effort: Effort;
  /**
   * Safety-classifier fallbacks: if the primary model declines a request, the
   * API transparently re-runs it on Anthropic's recommended fallback model.
   */
  fallbacks: boolean;
}

export class MissingApiKeyError extends Error {
  constructor(message: string) {
    super(message);
  }
}

/** Fallback params, spread into a request when enabled. */
export function fallbackParams(enabled: boolean) {
  return enabled
    ? { betas: ["server-side-fallback-2026-07-01"], fallbacks: "default" as const }
    : {};
}

/** Start a streaming Messages request with the app's shared defaults. */
export function streamMessage(
  client: Anthropic,
  options: ClaudeOptions,
  params: { system: string; messages: Anthropic.Beta.BetaMessageParam[]; maxTokens?: number },
) {
  // The beta namespace exposes the server-side `fallbacks` parameter.
  return client.beta.messages.stream({
    model: options.model,
    max_tokens: params.maxTokens ?? 16_000,
    system: params.system,
    messages: params.messages,
    output_config: { effort: options.effort },
    // Cache the (often long) source document so follow-up questions are cheaper and faster.
    cache_control: { type: "ephemeral" },
    ...fallbackParams(options.fallbacks),
  });
}

type MessageStream = ReturnType<typeof streamMessage>;

/** Map SDK errors to a short, user-facing message and HTTP status. */
export function describeError(error: unknown): { message: string; status: number } {
  if (error instanceof MissingApiKeyError) {
    return { message: error.message, status: 401 };
  }
  if (error instanceof Anthropic.AuthenticationError) {
    return { message: "The Anthropic API key is invalid. Check it and try again.", status: 401 };
  }
  if (error instanceof Anthropic.PermissionDeniedError) {
    return { message: "This API key doesn't have access to the configured model.", status: 403 };
  }
  if (error instanceof Anthropic.RateLimitError) {
    return { message: "Rate limited by the Anthropic API — please try again in a moment.", status: 429 };
  }
  if (error instanceof Anthropic.BadRequestError) {
    return { message: `The request was rejected: ${error.message}`, status: 400 };
  }
  if (error instanceof Anthropic.APIConnectionError) {
    return { message: "Couldn't reach the Anthropic API. Check your network connection.", status: 502 };
  }
  if (error instanceof Anthropic.APIError) {
    return { message: `Anthropic API error (${error.status ?? "unknown"}). Please try again.`, status: 502 };
  }
  console.error(error);
  return { message: "Something went wrong. Please try again.", status: 500 };
}

/**
 * Convert a Claude message stream into a plain-text streaming `Response`.
 *
 * Text deltas are forwarded as they arrive. If something goes wrong after the
 * response has started (the HTTP status is already 200), the error is sent
 * in-band after `STREAM_ERROR_MARKER` so the client can display it.
 */
export function toTextStreamResponse(stream: MessageStream, signal: AbortSignal): Response {
  const encoder = new TextEncoder();

  // Stop generating (and paying for) tokens if the user navigates away or cancels.
  signal.addEventListener("abort", () => stream.abort());

  const body = new ReadableStream<Uint8Array>({
    async start(controller) {
      try {
        for await (const event of stream) {
          if (event.type === "content_block_delta" && event.delta.type === "text_delta") {
            controller.enqueue(encoder.encode(event.delta.text));
          }
        }

        const final = await stream.finalMessage();
        if (final.stop_reason === "refusal") {
          controller.enqueue(
            encoder.encode(
              `${STREAM_ERROR_MARKER}Claude declined to analyze this content. Try different text.`,
            ),
          );
        } else if (final.stop_reason === "max_tokens") {
          controller.enqueue(
            encoder.encode(`${STREAM_ERROR_MARKER}The response was cut off because it reached the length limit.`),
          );
        }
      } catch (error) {
        if (!signal.aborted) {
          controller.enqueue(encoder.encode(`${STREAM_ERROR_MARKER}${describeError(error).message}`));
        }
      } finally {
        try {
          controller.close();
        } catch {
          // Already closed because the reader went away.
        }
      }
    },
    cancel() {
      stream.abort();
    },
  });

  return new Response(body, {
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      "X-Accel-Buffering": "no",
    },
  });
}

/** JSON error response for failures that happen before streaming starts. */
export function errorResponse(error: unknown): Response {
  const { message, status } = describeError(error);
  return Response.json({ error: message }, { status });
}
