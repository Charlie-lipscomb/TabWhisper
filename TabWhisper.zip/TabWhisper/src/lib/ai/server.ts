import "server-only";

import Anthropic from "@anthropic-ai/sdk";

import { type ClaudeOptions, DEFAULT_MODEL, MissingApiKeyError, parseEffort } from "./stream";

/**
 * Server-side Claude configuration (used when TabWhisper runs on a Node host
 * such as Vercel).
 *
 * The API key is read from `ANTHROPIC_API_KEY` and never leaves the server.
 * Model and effort can be overridden with environment variables so you can
 * trade quality for speed/cost without touching code.
 */
export const serverOptions: ClaudeOptions = {
  model: process.env.ANTHROPIC_MODEL || DEFAULT_MODEL,
  effort: parseEffort(process.env.ANTHROPIC_EFFORT),
  // Only the Claude API supports fallbacks — set ANTHROPIC_FALLBACKS=off when
  // pointing ANTHROPIC_BASE_URL at a proxy that rejects the parameter.
  fallbacks: process.env.ANTHROPIC_FALLBACKS !== "off",
};

let client: Anthropic | null = null;

/** Lazily construct a single shared client so a missing key surfaces as a friendly error. */
export function getServerClient(): Anthropic {
  if (!process.env.ANTHROPIC_API_KEY && !process.env.ANTHROPIC_AUTH_TOKEN) {
    throw new MissingApiKeyError(
      "ANTHROPIC_API_KEY is not set. Add it to .env.local (see README) and restart the server.",
    );
  }
  client ??= new Anthropic();
  return client;
}
