/**
 * Validation and prompt assembly for the two AI operations. Shared by the
 * server routes and the browser client so both enforce the same limits.
 */

import type Anthropic from "@anthropic-ai/sdk";

import { MAX_CONTENT_CHARS } from "@/lib/constants";

import { ANALYZE_SYSTEM_PROMPT, ASK_SYSTEM_PROMPT, buildAskMessages, formatDocument } from "./prompts";

const MAX_QUESTION_CHARS = 4_000;
const MAX_HISTORY_TURNS = 20;

export interface PreparedRequest {
  system: string;
  messages: Anthropic.Beta.BetaMessageParam[];
}

/** Either a ready-to-send request, or a JSON error response to return as-is. */
export type Prepared = { ok: true; request: PreparedRequest } | { ok: false; response: Response };

function reject(error: string, status: number): Prepared {
  return { ok: false, response: Response.json({ error }, { status }) };
}

type Turn = { question: string; answer: string };

function isTurn(value: unknown): value is Turn {
  return (
    typeof value === "object" &&
    value !== null &&
    typeof (value as Turn).question === "string" &&
    typeof (value as Turn).answer === "string"
  );
}

/** Body: `{ content, sourceUrl? }` */
export function prepareAnalyze(body: unknown): Prepared {
  const input = (body ?? {}) as { content?: unknown; sourceUrl?: unknown };
  const content = typeof input.content === "string" ? input.content.trim() : "";
  const sourceUrl = typeof input.sourceUrl === "string" ? input.sourceUrl : undefined;

  if (!content) return reject("Paste some text or load a URL first.", 400);
  if (content.length > MAX_CONTENT_CHARS) {
    return reject(
      `That's too long to analyze in one go (${content.length.toLocaleString()} characters; the limit is ${MAX_CONTENT_CHARS.toLocaleString()}). Try a shorter section.`,
      413,
    );
  }

  return {
    ok: true,
    request: {
      system: ANALYZE_SYSTEM_PROMPT,
      messages: [{ role: "user", content: formatDocument(content, sourceUrl) }],
    },
  };
}

/** Body: `{ content, sourceUrl?, question, history? }` */
export function prepareAsk(body: unknown): Prepared {
  const input = (body ?? {}) as {
    content?: unknown;
    sourceUrl?: unknown;
    question?: unknown;
    history?: unknown;
  };
  const content = typeof input.content === "string" ? input.content.trim() : "";
  const question = typeof input.question === "string" ? input.question.trim() : "";
  const sourceUrl = typeof input.sourceUrl === "string" ? input.sourceUrl : undefined;
  const history = Array.isArray(input.history)
    ? input.history.filter(isTurn).filter((turn) => turn.answer.trim()).slice(-MAX_HISTORY_TURNS)
    : [];

  if (!content) return reject("There's no content to ask about yet.", 400);
  if (!question) return reject("Please enter a question.", 400);
  if (content.length > MAX_CONTENT_CHARS || question.length > MAX_QUESTION_CHARS) {
    return reject("That request is too long.", 413);
  }

  return {
    ok: true,
    request: {
      system: ASK_SYSTEM_PROMPT,
      messages: buildAskMessages(content, sourceUrl, history, question),
    },
  };
}
