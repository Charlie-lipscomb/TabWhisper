/**
 * Values shared between the server routes and the browser.
 */

/** Prefix for in-band errors sent after a streaming response has started. */
export const STREAM_ERROR_MARKER = "\n\n\u0000TABWHISPER_ERROR:";

/** Headings the analysis prompt asks Claude to emit, in order. */
export const SECTION_HEADINGS = {
  title: "## Title",
  summary: "## Summary",
  keyPoints: "## Key Points",
  actionItems: "## Action Items",
} as const;

/** Upper bound on input size (~100K tokens). Larger inputs are rejected, never silently truncated. */
export const MAX_CONTENT_CHARS = 400_000;
