import "server-only";

import { lookup } from "node:dns/promises";
import { isIP } from "node:net";

import { Readability } from "@mozilla/readability";
import { parseHTML } from "linkedom";

const FETCH_TIMEOUT_MS = 15_000;
const MAX_HTML_BYTES = 5 * 1024 * 1024; // 5 MB
const MAX_REDIRECTS = 5;

export class ExtractError extends Error {
  constructor(
    message: string,
    public status = 400,
  ) {
    super(message);
  }
}

export interface ExtractedPage {
  title: string;
  content: string;
  url: string;
  siteName?: string;
  byline?: string;
}

/** Returns true for loopback, private, link-local, and other non-public addresses. */
function isPrivateAddress(address: string): boolean {
  if (isIP(address) === 6) {
    const lower = address.toLowerCase();
    // IPv4-mapped IPv6 (::ffff:10.0.0.1) — check the embedded IPv4 address.
    const mapped = lower.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    if (mapped) return isPrivateAddress(mapped[1]);
    return (
      lower === "::" ||
      lower === "::1" ||
      lower.startsWith("fc") ||
      lower.startsWith("fd") ||
      lower.startsWith("fe80")
    );
  }
  const [a, b] = address.split(".").map(Number);
  return (
    a === 0 ||
    a === 10 ||
    a === 127 ||
    (a === 100 && b >= 64 && b <= 127) || // carrier-grade NAT
    (a === 169 && b === 254) || // link-local / cloud metadata
    (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 168) ||
    a >= 224 // multicast & reserved
  );
}

/**
 * Validate a user-supplied URL and make sure it doesn't point at an internal
 * service (basic SSRF protection for the server-side fetch).
 */
async function assertPublicUrl(raw: string): Promise<URL> {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    throw new ExtractError("That doesn't look like a valid URL.");
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") {
    throw new ExtractError("Only http and https URLs are supported.");
  }

  const hostname = url.hostname.replace(/^\[|\]$/g, "");
  if (hostname === "localhost" || hostname.endsWith(".localhost") || hostname.endsWith(".internal")) {
    throw new ExtractError("Local and internal addresses can't be fetched.");
  }

  let addresses: string[];
  try {
    addresses = isIP(hostname)
      ? [hostname]
      : (await lookup(hostname, { all: true })).map((entry) => entry.address);
  } catch {
    throw new ExtractError(`Couldn't resolve ${hostname}.`);
  }
  if (addresses.some(isPrivateAddress)) {
    throw new ExtractError("Local and internal addresses can't be fetched.");
  }
  return url;
}

/** Fetch a URL, re-validating every redirect hop against the SSRF guard. */
async function fetchHtml(raw: string): Promise<{ html: string; finalUrl: string }> {
  let current = raw;

  for (let hop = 0; hop <= MAX_REDIRECTS; hop++) {
    const url = await assertPublicUrl(current);

    let response: Response;
    try {
      response = await fetch(url, {
        redirect: "manual",
        signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
        headers: {
          "User-Agent":
            "Mozilla/5.0 (compatible; TabWhisper/1.0; +https://github.com/charlie-lipscomb/tabwhisper)",
          Accept: "text/html,application/xhtml+xml;q=0.9,text/plain;q=0.8",
        },
      });
    } catch (error) {
      if (error instanceof Error && error.name === "TimeoutError") {
        throw new ExtractError("The page took too long to respond.", 504);
      }
      throw new ExtractError("Couldn't connect to that page.", 502);
    }

    if (response.status >= 300 && response.status < 400) {
      const location = response.headers.get("location");
      if (!location) throw new ExtractError("The page redirected without a destination.", 502);
      current = new URL(location, url).toString();
      continue;
    }

    if (!response.ok) {
      throw new ExtractError(`The page returned HTTP ${response.status}.`, 502);
    }

    const type = response.headers.get("content-type") ?? "";
    if (!/text\/html|application\/xhtml|text\/plain/i.test(type)) {
      throw new ExtractError("That URL isn't a web page (unsupported content type).", 415);
    }

    const declaredLength = Number(response.headers.get("content-length") ?? 0);
    if (declaredLength > MAX_HTML_BYTES) {
      throw new ExtractError("That page is too large to fetch.", 413);
    }

    const buffer = await response.arrayBuffer();
    if (buffer.byteLength > MAX_HTML_BYTES) {
      throw new ExtractError("That page is too large to fetch.", 413);
    }

    const text = new TextDecoder().decode(buffer);
    // Plain text responses are returned as-is (wrapped so Readability can read them).
    const html = /text\/plain/i.test(type) ? `<pre>${escapeHtml(text)}</pre>` : text;
    return { html, finalUrl: url.toString() };
  }

  throw new ExtractError("Too many redirects.", 502);
}

function escapeHtml(text: string): string {
  return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

/** Collapse runs of blank lines and trailing whitespace left over from HTML. */
function tidy(text: string): string {
  return text
    .replace(/\r\n/g, "\n")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

/**
 * Fetch a web page and extract its main readable content using Mozilla's
 * Readability (the engine behind Firefox Reader View).
 */
export async function extractFromUrl(raw: string): Promise<ExtractedPage> {
  const { html, finalUrl } = await fetchHtml(raw.trim());
  const { document } = parseHTML(html);

  // Readability's types expect a DOM Document; linkedom's is compatible at runtime.
  const article = new Readability(document as unknown as Document).parse();

  const fallbackText = tidy(document.body?.textContent ?? "");
  const content = tidy(article?.textContent ?? "") || fallbackText;

  if (content.length < 50) {
    throw new ExtractError(
      "Couldn't find readable content on that page. It may require JavaScript or a login — try pasting the text instead.",
      422,
    );
  }

  return {
    title: article?.title?.trim() || document.title?.trim() || new URL(finalUrl).hostname,
    content,
    url: finalUrl,
    siteName: article?.siteName ?? undefined,
    byline: article?.byline ?? undefined,
  };
}
