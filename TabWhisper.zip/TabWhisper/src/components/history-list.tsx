"use client";

import { ClockIcon, FileTextIcon, GlobeIcon, Trash2Icon } from "lucide-react";

import { Button } from "@/components/ui/button";
import type { Analysis } from "@/lib/history";
import { cn } from "@/lib/utils";

const relativeTime = new Intl.RelativeTimeFormat(undefined, { numeric: "auto" });

function timeAgo(timestamp: number): string {
  const seconds = Math.round((timestamp - Date.now()) / 1000);
  const units: [Intl.RelativeTimeFormatUnit, number][] = [
    ["day", 86_400],
    ["hour", 3_600],
    ["minute", 60],
  ];
  for (const [unit, size] of units) {
    if (Math.abs(seconds) >= size) return relativeTime.format(Math.round(seconds / size), unit);
  }
  return "just now";
}

interface HistoryListProps {
  items: Analysis[];
  activeId?: string;
  onSelect: (analysis: Analysis) => void;
  onDelete: (id: string) => void;
  onClear: () => void;
}

/** Recent analyses saved in this browser. */
export function HistoryList({ items, activeId, onSelect, onDelete, onClear }: HistoryListProps) {
  if (items.length === 0) return null;

  return (
    <section aria-labelledby="recent-heading" className="flex flex-col gap-3">
      <div className="flex items-center justify-between px-1">
        <h2 id="recent-heading" className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
          <ClockIcon className="size-4" /> Recent
        </h2>
        <Button variant="ghost" size="xs" className="text-muted-foreground" onClick={onClear}>
          Clear all
        </Button>
      </div>

      <ul className="flex flex-col gap-1">
        {items.map((item) => {
          const Icon = item.sourceUrl ? GlobeIcon : FileTextIcon;
          return (
            <li key={item.id} className="group relative">
              <button
                type="button"
                onClick={() => onSelect(item)}
                className={cn(
                  "flex w-full items-start gap-3 rounded-xl px-3 py-2.5 pr-10 text-left transition-colors hover:bg-muted",
                  item.id === activeId && "bg-secondary hover:bg-secondary",
                )}
              >
                <Icon className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
                <span className="min-w-0">
                  <span className="line-clamp-2 text-sm font-medium">{item.title || "Untitled"}</span>
                  <span className="mt-0.5 block truncate text-xs text-muted-foreground">
                    {item.sourceUrl ? new URL(item.sourceUrl).hostname : "Pasted text"} · {timeAgo(item.createdAt)}
                  </span>
                </span>
              </button>
              <Button
                variant="ghost"
                size="icon-xs"
                className="absolute top-2.5 right-2 text-muted-foreground opacity-100 group-hover:opacity-100 focus-visible:opacity-100 sm:opacity-0"
                onClick={() => onDelete(item.id)}
                aria-label={`Delete “${item.title}”`}
              >
                <Trash2Icon />
              </Button>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
