"use client";

import { ArrowUpIcon, MessageCircleQuestionIcon, SquareIcon } from "lucide-react";
import { useEffect, useRef, useState } from "react";

import { Markdown } from "@/components/markdown";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import type { QATurn } from "@/lib/history";

const SUGGESTIONS = [
  "What's the strongest argument here?",
  "What are the main risks or open questions?",
  "Explain this to me like I'm new to the topic.",
  "What evidence supports the key claims?",
];

interface QAPanelProps {
  turns: QATurn[];
  /** The question currently being answered, if any. */
  pendingQuestion: string | null;
  pendingAnswer: string;
  pendingError: string | null;
  streaming: boolean;
  disabled: boolean;
  onAsk: (question: string) => void;
  onStop: () => void;
}

/** Follow-up questions about the analyzed content, with streaming answers. */
export function QAPanel({
  turns,
  pendingQuestion,
  pendingAnswer,
  pendingError,
  streaming,
  disabled,
  onAsk,
  onStop,
}: QAPanelProps) {
  const [question, setQuestion] = useState("");
  const endRef = useRef<HTMLDivElement>(null);

  // Keep the newest answer in view while it streams.
  useEffect(() => {
    if (pendingQuestion) endRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, [pendingQuestion, pendingAnswer]);

  function submit(text = question) {
    const trimmed = text.trim();
    if (!trimmed || streaming || disabled) return;
    onAsk(trimmed);
    setQuestion("");
  }

  const empty = turns.length === 0 && !pendingQuestion;

  return (
    <div className="flex flex-col gap-6">
      {empty && (
        <div className="flex flex-col items-center gap-4 py-6 text-center">
          <div className="flex size-11 items-center justify-center rounded-full bg-secondary text-primary">
            <MessageCircleQuestionIcon className="size-5" />
          </div>
          <div>
            <p className="font-medium">Ask anything about this content</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Answers are grounded in the text you analyzed.
            </p>
          </div>
          <div className="flex max-w-xl flex-wrap justify-center gap-2">
            {SUGGESTIONS.map((suggestion) => (
              <Button
                key={suggestion}
                variant="outline"
                size="sm"
                className="h-auto rounded-full px-3 py-1.5 font-normal whitespace-normal"
                disabled={disabled}
                onClick={() => submit(suggestion)}
              >
                {suggestion}
              </Button>
            ))}
          </div>
        </div>
      )}

      {turns.map((turn, index) => (
        <QATurnView key={index} question={turn.question} answer={turn.answer} />
      ))}

      {pendingQuestion && (
        <QATurnView
          question={pendingQuestion}
          answer={pendingAnswer}
          streaming={streaming}
          error={pendingError}
        />
      )}
      <div ref={endRef} />

      <form
        className="sticky bottom-3 flex items-end gap-2 rounded-2xl border bg-card/95 p-2 shadow-lg shadow-black/5 backdrop-blur supports-backdrop-filter:bg-card/80"
        onSubmit={(event) => {
          event.preventDefault();
          submit();
        }}
      >
        <Textarea
          value={question}
          onChange={(event) => setQuestion(event.target.value)}
          onKeyDown={(event) => {
            // Enter sends; Shift+Enter adds a newline.
            if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing) {
              event.preventDefault();
              submit();
            }
          }}
          placeholder={disabled ? "Waiting for the analysis to finish…" : "Ask a follow-up question…"}
          aria-label="Ask a question"
          disabled={disabled}
          rows={1}
          className="max-h-40 min-h-10 resize-none border-0 bg-transparent px-2.5 py-2 shadow-none focus-visible:ring-0 dark:bg-transparent"
        />
        {streaming ? (
          <Button type="button" size="icon" variant="secondary" onClick={onStop} aria-label="Stop answering">
            <SquareIcon className="fill-current" />
          </Button>
        ) : (
          <Button type="submit" size="icon" disabled={!question.trim() || disabled} aria-label="Send question">
            <ArrowUpIcon />
          </Button>
        )}
      </form>
    </div>
  );
}

function QATurnView({
  question,
  answer,
  streaming = false,
  error = null,
}: {
  question: string;
  answer: string;
  streaming?: boolean;
  error?: string | null;
}) {
  return (
    <div className="flex flex-col gap-3">
      <div className="ml-auto max-w-[85%] rounded-2xl rounded-br-md bg-secondary px-4 py-2.5 text-[0.95rem] whitespace-pre-wrap text-secondary-foreground">
        {question}
      </div>
      <div className="max-w-full">
        {answer ? (
          <Markdown streaming={streaming}>{answer}</Markdown>
        ) : streaming ? (
          <ThinkingDots />
        ) : null}
        {error && <p className="mt-2 text-sm text-destructive">{error}</p>}
      </div>
    </div>
  );
}

/** Subtle three-dot indicator while waiting for the first token. */
export function ThinkingDots({ label = "Thinking" }: { label?: string }) {
  return (
    <div className="flex items-center gap-2 text-sm text-muted-foreground" role="status">
      <span className="flex gap-1">
        {[0, 1, 2].map((i) => (
          <span
            key={i}
            className="size-1.5 animate-bounce rounded-full bg-primary/60"
            style={{ animationDelay: `${i * 150}ms` }}
          />
        ))}
      </span>
      {label}…
    </div>
  );
}
