import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

import { cn } from "@/lib/utils";

/** Renders model output as GitHub-flavored Markdown with TabWhisper's prose styles. */
export function Markdown({
  children,
  streaming = false,
  className,
}: {
  children: string;
  streaming?: boolean;
  className?: string;
}) {
  return (
    <div className={cn("markdown", streaming && "streaming-caret", className)}>
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          // Open links from the model in a new tab, safely.
          a: ({ href, children }) => (
            <a href={href} target="_blank" rel="noopener noreferrer">
              {children}
            </a>
          ),
        }}
      >
        {children}
      </ReactMarkdown>
    </div>
  );
}
