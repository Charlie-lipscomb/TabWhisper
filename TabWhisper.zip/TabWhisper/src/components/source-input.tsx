"use client";

import { GlobeIcon, Loader2Icon, SparklesIcon, XIcon } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { MAX_CONTENT_CHARS } from "@/lib/constants";
import { cn } from "@/lib/utils";

/** True when the input is a single http(s) URL rather than prose. */
export function looksLikeUrl(value: string): boolean {
  const trimmed = value.trim();
  if (!trimmed || /\s/.test(trimmed)) return false;
  try {
    const url = new URL(/^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`);
    return url.hostname.includes(".") && /^https?:$/.test(url.protocol);
  } catch {
    return false;
  }
}

export interface LoadedSource {
  url: string;
  title: string;
}

interface SourceInputProps {
  value: string;
  onChange: (value: string) => void;
  source: LoadedSource | null;
  onClearSource: () => void;
  onLoadUrl: () => void;
  onAnalyze: () => void;
  loadingUrl: boolean;
  busy: boolean;
}

/** The big paste area with "Load from URL" and "Analyze" actions. */
export function SourceInput({
  value,
  onChange,
  source,
  onClearSource,
  onLoadUrl,
  onAnalyze,
  loadingUrl,
  busy,
}: SourceInputProps) {
  const isUrl = looksLikeUrl(value);
  const tooLong = value.length > MAX_CONTENT_CHARS;
  const canAnalyze = value.trim().length > 0 && !tooLong && !busy;

  return (
    <Card className="relative gap-0 overflow-hidden p-0 shadow-[0_1px_2px_rgb(0_0_0/0.04),0_12px_40px_-12px_var(--glow)] transition-shadow focus-within:shadow-[0_1px_2px_rgb(0_0_0/0.04),0_16px_50px_-10px_var(--glow)]">
      {source && (
        <div className="flex items-center gap-2 border-b bg-muted/40 px-4 py-2.5 text-sm sm:px-5">
          <GlobeIcon className="size-4 shrink-0 text-primary" />
          <span className="truncate font-medium">{source.title}</span>
          <span className="hidden truncate text-muted-foreground sm:inline">
            · {new URL(source.url).hostname}
          </span>
          <Button
            variant="ghost"
            size="icon-xs"
            className="ml-auto"
            onClick={onClearSource}
            aria-label="Clear loaded page"
          >
            <XIcon />
          </Button>
        </div>
      )}

      <Textarea
        value={value}
        onChange={(event) => onChange(event.target.value)}
        onKeyDown={(event) => {
          // ⌘/Ctrl + Enter to analyze.
          if (event.key === "Enter" && (event.metaKey || event.ctrlKey) && canAnalyze) {
            event.preventDefault();
            onAnalyze();
          }
        }}
        placeholder="Paste a URL, an article, meeting notes, documentation…"
        aria-label="Content to analyze"
        autoFocus
        className="field-sizing-fixed max-h-[55vh] min-h-56 resize-none rounded-none border-0 bg-transparent px-4 py-4 text-base leading-7 shadow-none focus-visible:ring-0 sm:min-h-64 sm:px-5 sm:py-5 md:text-base dark:bg-transparent"
      />

      <div className="flex flex-wrap items-center gap-2 border-t bg-muted/30 px-3 py-3 sm:px-4">
        <div className="flex min-w-0 items-center gap-2 text-xs text-muted-foreground">
          {isUrl ? (
            <Badge variant="secondary" className="gap-1">
              <GlobeIcon className="size-3" /> URL detected
            </Badge>
          ) : (
            <span className={cn(tooLong && "font-medium text-destructive")}>
              {value.length.toLocaleString()} characters
              {tooLong && ` — limit is ${MAX_CONTENT_CHARS.toLocaleString()}`}
            </span>
          )}
        </div>

        <div className="ml-auto flex items-center gap-2">
          <Button
            variant="outline"
            onClick={onLoadUrl}
            disabled={!isUrl || loadingUrl || busy}
            className="h-9 px-3"
          >
            {loadingUrl ? <Loader2Icon className="animate-spin" /> : <GlobeIcon />}
            <span>Load from URL</span>
          </Button>
          <Button onClick={onAnalyze} disabled={!canAnalyze} className="h-9 px-4">
            {busy ? <Loader2Icon className="animate-spin" /> : <SparklesIcon />}
            <span>Analyze</span>
            <kbd className="ml-1 hidden rounded bg-primary-foreground/15 px-1.5 font-mono text-[10px] sm:inline">
              ⌘↵
            </kbd>
          </Button>
        </div>
      </div>
    </Card>
  );
}
