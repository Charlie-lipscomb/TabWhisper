"use client";

import { FeatherIcon, KeyRoundIcon, SettingsIcon } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";

import { HistoryList } from "@/components/history-list";
import { ResultsView } from "@/components/results-view";
import { SettingsDialog, useBrowserSettings } from "@/components/settings-dialog";
import { type LoadedSource, looksLikeUrl, SourceInput } from "@/components/source-input";
import { ThemeToggle } from "@/components/theme-toggle";
import { Button } from "@/components/ui/button";
import { useTextStream } from "@/hooks/use-text-stream";
import { IS_STATIC, requestAnalysis, requestAnswer, requestExtract } from "@/lib/api";
import { type Analysis, createId, loadHistory, saveHistory, upsertAnalysis } from "@/lib/history";
import { parseSections } from "@/lib/sections";
import { cn } from "@/lib/utils";

interface ExtractResponse {
  title: string;
  content: string;
  url: string;
  error?: string;
}

/** Normalise "example.com/post" to "https://example.com/post". */
function normaliseUrl(value: string): string {
  const trimmed = value.trim();
  return /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
}

/** Fallback title for pasted text: its first few words. */
function titleFromText(text: string): string {
  const words = text.trim().split(/\s+/).slice(0, 8).join(" ");
  return words.length < text.trim().length ? `${words}…` : words;
}

/**
 * Top-level client component: owns the input, the current analysis, the Q&A
 * stream, and the localStorage-backed history.
 */
export function TabWhisperApp() {
  const [input, setInput] = useState("");
  const [source, setSource] = useState<LoadedSource | null>(null);
  const [loadingUrl, setLoadingUrl] = useState(false);
  const [current, setCurrent] = useState<Analysis | null>(null);
  const [history, setHistory] = useState<Analysis[]>([]);
  const [pendingQuestion, setPendingQuestion] = useState<string | null>(null);

  // Static deployments (GitHub Pages) need the visitor's own API key.
  const settings = useBrowserSettings();
  const [settingsOpen, setSettingsOpen] = useState(false);
  const needsKey = IS_STATIC && !settings.apiKey;

  /** In static mode, prompt for an API key before any request. Returns false if missing. */
  function ensureKey(): boolean {
    if (!needsKey) return true;
    setSettingsOpen(true);
    return false;
  }

  const analysisStream = useTextStream();
  const qaStream = useTextStream();

  // Keep a ref to the latest analysis so async stream callbacks never use stale state.
  const currentRef = useRef<Analysis | null>(null);
  useEffect(() => {
    currentRef.current = current;
  }, [current]);

  // localStorage only exists in the browser, so load history after mount.
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- one-time hydration from browser storage
    setHistory(loadHistory());
  }, []);

  const persist = useCallback((analysis: Analysis) => {
    setHistory((items) => saveHistory(upsertAnalysis(items, analysis)));
  }, []);

  /** Fetch a URL (server-side, or via Claude's web fetch tool in static mode) and return its readable text. */
  const loadUrl = useCallback(async (raw: string): Promise<LoadedSource & { content: string } | null> => {
    setLoadingUrl(true);
    try {
      const response = await requestExtract(normaliseUrl(raw));
      const data = (await response.json().catch(() => null)) as ExtractResponse | null;
      if (!response.ok || !data || data.error) {
        toast.error(data?.error ?? "Couldn't load that page.");
        return null;
      }
      return { url: data.url, title: data.title, content: data.content };
    } catch {
      toast.error("Couldn't load that page. Check your connection.");
      return null;
    } finally {
      setLoadingUrl(false);
    }
  }, []);

  /** "Load from URL": replace the URL in the text area with the page's content. */
  async function handleLoadUrl() {
    if (!ensureKey()) return;
    const page = await loadUrl(input);
    if (!page) return;
    setInput(page.content);
    setSource({ url: page.url, title: page.title });
    toast.success(`Loaded “${page.title}”`);
  }

  /** Run (or re-run) the analysis stream for an analysis record. */
  async function runAnalysis(analysis: Analysis) {
    setCurrent(analysis);
    let latestText = "";
    const result = await analysisStream.run(
      (signal) => requestAnalysis({ content: analysis.content, sourceUrl: analysis.sourceUrl }, signal),
      {
        onUpdate: (text) => {
          latestText = text;
          setCurrent((prev) => (prev && prev.id === analysis.id ? { ...prev, result: text } : prev));
        },
      },
    );

    // Save whatever we got (complete, or partial after stop/error) so it shows up in Recent.
    const text = result ?? latestText;
    if (text.trim()) {
      const finished = { ...analysis, result: text, title: parseSections(text).title || analysis.title };
      setCurrent((prev) => (prev && prev.id === analysis.id ? finished : prev));
      persist(finished);
    }
  }

  async function handleAnalyze() {
    if (!ensureKey()) return;
    let content = input.trim();
    let loaded = source;

    // A bare URL in the box: load the page first, then analyze it.
    if (looksLikeUrl(content)) {
      const page = await loadUrl(content);
      if (!page) return;
      content = page.content;
      loaded = { url: page.url, title: page.title };
      setInput(page.content);
      setSource(loaded);
    }
    if (!content) return;

    qaStream.reset();
    setPendingQuestion(null);
    void runAnalysis({
      id: createId(),
      createdAt: Date.now(),
      title: loaded?.title ?? titleFromText(content),
      content,
      sourceUrl: loaded?.url,
      result: "",
      qa: [],
    });
  }

  async function handleAsk(question: string) {
    const analysis = currentRef.current;
    if (!analysis || !ensureKey()) return;

    setPendingQuestion(question);
    const answer = await qaStream.run((signal) =>
      requestAnswer(
        { content: analysis.content, sourceUrl: analysis.sourceUrl, question, history: analysis.qa },
        signal,
      ),
    );

    if (answer?.trim()) {
      // Commit the turn and clear the pending slot.
      const latest = currentRef.current;
      if (latest && latest.id === analysis.id) {
        const updated = { ...latest, qa: [...latest.qa, { question, answer }] };
        setCurrent(updated);
        persist(updated);
      }
      setPendingQuestion(null);
      qaStream.reset();
    }
  }

  /** Commit a partially streamed answer when the user presses stop. */
  function handleStopAsk() {
    qaStream.stop();
    const latest = currentRef.current;
    if (latest && pendingQuestion && qaStream.text.trim()) {
      const updated = { ...latest, qa: [...latest.qa, { question: pendingQuestion, answer: qaStream.text }] };
      setCurrent(updated);
      persist(updated);
      setPendingQuestion(null);
      qaStream.reset();
    }
  }

  function handleNew() {
    analysisStream.reset();
    qaStream.reset();
    setPendingQuestion(null);
    setCurrent(null);
    setInput("");
    setSource(null);
  }

  function handleSelect(item: Analysis) {
    analysisStream.reset();
    qaStream.reset();
    setPendingQuestion(null);
    setCurrent(item);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function handleDelete(id: string) {
    setHistory((items) => saveHistory(items.filter((item) => item.id !== id)));
  }

  function handleClearHistory() {
    setHistory(saveHistory([]));
    toast("Recent analyses cleared.");
  }

  const analyzing = analysisStream.status === "streaming";

  return (
    <div className="relative flex min-h-full flex-1 flex-col">
      {/* Soft ambient glow behind the page */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[420px] bg-[radial-gradient(60%_60%_at_50%_0%,var(--glow),transparent)]"
      />

      <header className="mx-auto flex w-full max-w-6xl items-center justify-between px-4 py-5 sm:px-6">
        <button type="button" onClick={handleNew} className="flex items-center gap-2.5" aria-label="TabWhisper home">
          <span className="flex size-8 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm">
            <FeatherIcon className="size-4" />
          </span>
          <span className="font-heading text-xl font-medium tracking-tight">TabWhisper</span>
        </button>
        <div className="flex items-center gap-1">
          {IS_STATIC && (
            <Button variant="ghost" size="icon" aria-label="Settings" onClick={() => setSettingsOpen(true)}>
              <SettingsIcon />
            </Button>
          )}
          <ThemeToggle />
        </div>
      </header>

      {IS_STATIC && <SettingsDialog open={settingsOpen} onOpenChange={setSettingsOpen} />}

      <main
        className={cn(
          "mx-auto grid w-full flex-1 gap-10 px-4 pb-16 sm:px-6",
          // Only reserve a sidebar column once there's history to show.
          history.length > 0 ? "max-w-6xl lg:grid-cols-[minmax(0,1fr)_260px]" : "max-w-3xl",
        )}
      >
        <div className="min-w-0">
          {current ? (
            <ResultsView
              key={current.id}
              analysis={current}
              streaming={analyzing}
              error={analysisStream.error}
              onStop={analysisStream.stop}
              onRetry={() => {
                if (ensureKey()) void runAnalysis({ ...current, result: "", qa: [] });
              }}
              onNew={handleNew}
              qa={{
                pendingQuestion,
                pendingAnswer: qaStream.text,
                pendingError: qaStream.error,
                streaming: qaStream.status === "streaming",
                onAsk: handleAsk,
                onStop: handleStopAsk,
              }}
            />
          ) : (
            <div className="flex flex-col gap-8 pt-6 sm:pt-12">
              <div className="flex flex-col gap-3 text-center">
                <h1 className="font-heading text-4xl font-medium tracking-tight text-balance sm:text-5xl">
                  Read less. <span className="text-primary italic">Understand more.</span>
                </h1>
                <p className="mx-auto max-w-lg text-base text-pretty text-muted-foreground sm:text-lg">
                  Paste a link or any text. Get a summary, key points, action items — and ask it anything.
                </p>
              </div>
              {needsKey && (
                <button
                  type="button"
                  onClick={() => setSettingsOpen(true)}
                  className="mx-auto flex items-center gap-2 rounded-full border bg-card px-4 py-2 text-sm shadow-sm transition-colors hover:bg-muted"
                >
                  <KeyRoundIcon className="size-4 text-primary" />
                  Add your Anthropic API key to get started
                </button>
              )}
              <SourceInput
                value={input}
                onChange={(value) => {
                  setInput(value);
                  if (!value.trim()) setSource(null);
                }}
                source={source}
                onClearSource={() => {
                  setSource(null);
                  setInput("");
                }}
                onLoadUrl={handleLoadUrl}
                onAnalyze={handleAnalyze}
                loadingUrl={loadingUrl}
                busy={loadingUrl || analyzing}
              />
            </div>
          )}
        </div>

        <aside className="lg:pt-2">
          <div className="lg:sticky lg:top-6">
            <HistoryList
              items={history}
              activeId={current?.id}
              onSelect={handleSelect}
              onDelete={handleDelete}
              onClear={handleClearHistory}
            />
          </div>
        </aside>
      </main>

      <footer className="mx-auto w-full max-w-6xl px-4 pb-8 text-center text-xs text-muted-foreground sm:px-6">
        Powered by Claude · {IS_STATIC ? "Your API key and history" : "Your history"} stay in this browser.
      </footer>
    </div>
  );
}
