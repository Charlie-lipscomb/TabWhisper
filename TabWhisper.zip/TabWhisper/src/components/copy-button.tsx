"use client";

import { CheckIcon, CopyIcon } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";

/** Copies text to the clipboard and briefly confirms with a checkmark. */
export function CopyButton({
  text,
  label = "Copy",
  disabled,
}: {
  text: string;
  label?: string;
  disabled?: boolean;
}) {
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!copied) return;
    const timeout = setTimeout(() => setCopied(false), 1600);
    return () => clearTimeout(timeout);
  }, [copied]);

  async function copy() {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
    } catch {
      toast.error("Couldn't access the clipboard.");
    }
  }

  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={copy}
      disabled={disabled || !text.trim()}
      aria-label={label}
      className="text-muted-foreground"
    >
      {copied ? <CheckIcon className="text-primary" /> : <CopyIcon />}
      <span>{copied ? "Copied" : label}</span>
    </Button>
  );
}
