"use client";

import {
  AlignLeftIcon,
  ChevronDownIcon,
  ExternalLinkIcon,
  ListChecksIcon,
  ListIcon,
  MessagesSquareIcon,
  PlusIcon,
  RotateCwIcon,
  SquareIcon,
} from "lucide-react";
import { useState } from "react";

import { CopyButton } from "@/components/copy-button";
import { Markdown } from "@/components/markdown";
import { QAPanel } from "@/components/qa-panel";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { Analysis } from "@/lib/history";
import { parseSections, type SectionKey } from "@/lib/sections";

type TabKey = Exclude<SectionKey, "title"> | "qa";

const TABS: { key: TabKey; label: string; short: string; icon: typeof ListIcon }[] = [
  { key: "summary", label: "Summary", short: "Summary", icon: AlignLeftIcon },
  { key: "keyPoints", label: "Key Points", short: "Points", icon: ListIcon },
  { key: "actionItems", label: "Action Items", short: "Actions", icon: ListChecksIcon },
  { key: "qa", label: "Q&A", short: "Q&A", icon: MessagesSquareIcon },
];

interface ResultsViewProps {
  analysis: Analysis;
  streaming: boolean;
  error: string | null;
  onStop: () => void;
  onRetry: () => void;
  onNew: () => void;
  qa: {
    pendingQuestion: string | null;
    pendingAnswer: string;
    pendingError: string | null;
    streaming: boolean;
    onAsk: (question: string) => void;
    onStop: () => void;
  };
}

/** Card-based results: a header with the title and tabs for each section. */
export function ResultsView({ analysis, streaming, error, onStop, onRetry, onNew, qa }: ResultsViewProps) {
  const [tab, setTab] = useState<TabKey>("summary");
  const [showSource, setShowSource] = useState(false);
  const sections = parseSections(analysis.result);
  const title = sections.title || analysis.title;

  const sourceLabel = analysis.sourceUrl ? new URL(analysis.sourceUrl).hostname : "Pasted text";

  return (
    <div className="flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0">
          <div className="mb-2 flex flex-wrap items-center gap-x-2 gap-y-1 text-sm text-muted-foreground">
            {analysis.sourceUrl ? (
              <a
                href={analysis.sourceUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 hover:text-foreground"
              >
                {sourceLabel}
                <ExternalLinkIcon className="size-3.5" />
              </a>
            ) : (
              <span>{sourceLabel}</span>
            )}
            <span aria-hidden>·</span>
            <span>{Math.max(1, Math.round(analysis.content.split(/\s+/).length / 230))} min read</span>
            <span aria-hidden>·</span>
            <button
              type="button"
              onClick={() => setShowSource((v) => !v)}
              className="inline-flex items-center gap-0.5 hover:text-foreground"
              aria-expanded={showSource}
            >
              {showSource ? "Hide" : "View"} source
              <ChevronDownIcon className={`size-3.5 transition-transform ${showSource ? "rotate-180" : ""}`} />
            </button>
          </div>
          {title ? (
            <h1 className="font-heading text-3xl leading-tight font-medium tracking-tight text-balance sm:text-4xl">
              {title}
            </h1>
          ) : (
            <Skeleton className="h-10 w-3/4 max-w-md" />
          )}
        </div>

        <div className="flex shrink-0 items-center gap-2">
          {streaming ? (
            <Button variant="outline" onClick={onStop}>
              <SquareIcon className="fill-current" /> Stop
            </Button>
          ) : (
            <CopyButton text={analysis.result.replace(/^## Title\s*\n.*\n?/m, `# ${title}\n`)} label="Copy all" />
          )}
          <Button variant="secondary" onClick={onNew}>
            <PlusIcon /> New analysis
          </Button>
        </div>
      </div>

      {showSource && (
        <Card className="max-h-80 overflow-y-auto bg-muted/30 py-4">
          <CardContent className="text-sm leading-6 whitespace-pre-wrap text-muted-foreground">
            {analysis.content}
          </CardContent>
        </Card>
      )}

      {error && (
        <div
          role="alert"
          className="flex flex-col gap-3 rounded-xl border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm sm:flex-row sm:items-center sm:justify-between"
        >
          <span className="text-destructive">{error}</span>
          <Button variant="outline" size="sm" onClick={onRetry}>
            <RotateCwIcon /> Try again
          </Button>
        </div>
      )}

      {/* Sections */}
      <Tabs value={tab} onValueChange={(value) => setTab(value as TabKey)} className="gap-5">
        <TabsList className="grid h-10! w-full grid-cols-4 sm:inline-flex sm:w-fit">
          {TABS.map(({ key, label, short, icon: Icon }) => (
            <TabsTrigger key={key} value={key} aria-label={label} className="px-2 text-xs sm:px-3 sm:text-sm">
              <Icon className="hidden min-[400px]:block" />
              <span className="sm:hidden">{short}</span>
              <span className="hidden sm:inline">{label}</span>
              {key === "qa" && analysis.qa.length > 0 && (
                <span className="rounded-full bg-primary/15 px-1.5 text-[11px] text-primary">
                  {analysis.qa.length}
                </span>
              )}
            </TabsTrigger>
          ))}
        </TabsList>

        {(["summary", "keyPoints", "actionItems"] as const).map((key) => (
          <TabsContent key={key} value={key}>
            <SectionCard
              label={TABS.find((t) => t.key === key)!.label}
              text={sections[key]}
              // A section is "live" while it's the last one Claude has started writing.
              streaming={streaming && isActiveSection(sections, key)}
              pending={streaming && !sections[key]}
            />
          </TabsContent>
        ))}

        <TabsContent value="qa">
          <QAPanel
            turns={analysis.qa}
            pendingQuestion={qa.pendingQuestion}
            pendingAnswer={qa.pendingAnswer}
            pendingError={qa.pendingError}
            streaming={qa.streaming}
            disabled={streaming}
            onAsk={qa.onAsk}
            onStop={qa.onStop}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}

/** True if `key` is the furthest section with content so far. */
function isActiveSection(sections: ReturnType<typeof parseSections>, key: SectionKey): boolean {
  const order: SectionKey[] = ["summary", "keyPoints", "actionItems"];
  const last = [...order].reverse().find((k) => sections[k]);
  return last === key;
}

function SectionCard({
  label,
  text,
  streaming,
  pending,
}: {
  label: string;
  text: string;
  streaming: boolean;
  pending: boolean;
}) {
  return (
    <Card className="gap-0 py-0">
      <div className="flex items-center justify-between border-b px-5 py-2.5 sm:px-6">
        <h2 className="text-sm font-medium text-muted-foreground">{label}</h2>
        <CopyButton text={text} disabled={streaming} />
      </div>
      <CardContent className="px-5 py-6 sm:px-8 sm:py-8">
        {text ? (
          <Markdown streaming={streaming}>{text}</Markdown>
        ) : pending ? (
          <div className="flex flex-col gap-3" aria-label="Loading">
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-11/12" />
            <Skeleton className="h-4 w-4/5" />
            <Skeleton className="h-4 w-2/3" />
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">Nothing here yet.</p>
        )}
      </CardContent>
    </Card>
  );
}
