"use client";

import { EyeIcon, EyeOffIcon, KeyRoundIcon, ShieldCheckIcon } from "lucide-react";
import { useState, useSyncExternalStore } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  type BrowserSettings,
  getServerSettings,
  getSettings,
  saveSettings,
  subscribeSettings,
} from "@/lib/ai/browser";
import { EFFORTS, type Effort } from "@/lib/ai/stream";

/** Live view of the browser settings (static / bring-your-own-key mode). */
export function useBrowserSettings(): BrowserSettings {
  return useSyncExternalStore(subscribeSettings, getSettings, getServerSettings);
}

interface SettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

/** Lets visitors of a static deployment enter their own Anthropic API key. */
export function SettingsDialog({ open, onOpenChange }: SettingsDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        {/* Remount the form each time so it starts from the saved values. */}
        {open && <SettingsForm onDone={() => onOpenChange(false)} />}
      </DialogContent>
    </Dialog>
  );
}

function SettingsForm({ onDone }: { onDone: () => void }) {
  const saved = getSettings();
  const [apiKey, setApiKey] = useState(saved.apiKey);
  const [model, setModel] = useState(saved.model);
  const [effort, setEffort] = useState<Effort>(saved.effort);
  const [reveal, setReveal] = useState(false);

  return (
    <form
      className="grid gap-5"
      onSubmit={(event) => {
        event.preventDefault();
        saveSettings({ apiKey, model, effort });
        toast.success(apiKey.trim() ? "Settings saved." : "API key removed.");
        onDone();
      }}
    >
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          <KeyRoundIcon className="size-4 text-primary" /> Your Anthropic API key
        </DialogTitle>
        <DialogDescription>
          This site runs entirely in your browser. Your key is saved only on this device and sent only to
          Anthropic&apos;s API. Get one from the{" "}
          <a
            href="https://platform.claude.com/settings/keys"
            target="_blank"
            rel="noopener noreferrer"
            className="text-primary underline underline-offset-4"
          >
            Claude Console
          </a>
          .
        </DialogDescription>
      </DialogHeader>

      <div className="grid gap-2">
        <Label htmlFor="api-key">API key</Label>
        <div className="flex gap-2">
          <Input
            id="api-key"
            type={reveal ? "text" : "password"}
            value={apiKey}
            onChange={(event) => setApiKey(event.target.value)}
            placeholder="sk-ant-…"
            autoComplete="off"
            spellCheck={false}
            className="h-9 font-mono"
            autoFocus
          />
          <Button
            type="button"
            variant="outline"
            size="icon"
            className="size-9"
            onClick={() => setReveal((value) => !value)}
            aria-label={reveal ? "Hide key" : "Show key"}
          >
            {reveal ? <EyeOffIcon /> : <EyeIcon />}
          </Button>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div className="grid gap-2">
          <Label htmlFor="model">Model</Label>
          <Input
            id="model"
            value={model}
            onChange={(event) => setModel(event.target.value)}
            spellCheck={false}
            className="h-9 font-mono text-sm"
          />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="effort">Effort</Label>
          <select
            id="effort"
            value={effort}
            onChange={(event) => setEffort(event.target.value as Effort)}
            className="h-9 rounded-lg border border-input bg-transparent px-2.5 text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 dark:bg-input/30"
          >
            {EFFORTS.map((value) => (
              <option key={value} value={value}>
                {value}
              </option>
            ))}
          </select>
        </div>
      </div>

      <p className="flex items-start gap-2 text-xs text-muted-foreground">
        <ShieldCheckIcon className="mt-0.5 size-3.5 shrink-0" />
        Only use your key on devices you trust. You can remove it at any time.
      </p>

      <DialogFooter className="gap-2">
        {saved.apiKey && (
          <Button
            type="button"
            variant="ghost"
            className="text-destructive sm:mr-auto"
            onClick={() => {
              saveSettings({ apiKey: "", model, effort });
              toast("API key removed from this browser.");
              onDone();
            }}
          >
            Remove key
          </Button>
        )}
        <Button type="submit">Save</Button>
      </DialogFooter>
    </form>
  );
}
