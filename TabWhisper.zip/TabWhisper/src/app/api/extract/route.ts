import { ExtractError, extractFromUrl } from "@/lib/extract";

/** POST /api/extract — fetch a URL and return its main readable content. */
export async function POST(request: Request) {
  const body = (await request.json().catch(() => null)) as { url?: unknown } | null;
  const url = typeof body?.url === "string" ? body.url.trim() : "";

  if (!url) {
    return Response.json({ error: "Please provide a URL." }, { status: 400 });
  }

  try {
    const page = await extractFromUrl(url);
    return Response.json(page);
  } catch (error) {
    if (error instanceof ExtractError) {
      return Response.json({ error: error.message }, { status: error.status });
    }
    console.error("Extraction failed", error);
    return Response.json({ error: "Couldn't load that page." }, { status: 500 });
  }
}
