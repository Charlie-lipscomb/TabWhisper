import { prepareAsk } from "@/lib/ai/requests";
import { getServerClient, serverOptions } from "@/lib/ai/server";
import { errorResponse, streamMessage, toTextStreamResponse } from "@/lib/ai/stream";

export const maxDuration = 300;

/**
 * POST /api/ask — stream an answer to a follow-up question about the content.
 * The client sends prior Q&A turns so the conversation keeps its context.
 */
export async function POST(request: Request) {
  const prepared = prepareAsk(await request.json().catch(() => null));
  if (!prepared.ok) return prepared.response;

  try {
    const stream = streamMessage(getServerClient(), serverOptions, prepared.request);
    return toTextStreamResponse(stream, request.signal);
  } catch (error) {
    return errorResponse(error);
  }
}
