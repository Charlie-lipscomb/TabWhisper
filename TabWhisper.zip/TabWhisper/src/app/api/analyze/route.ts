import { prepareAnalyze } from "@/lib/ai/requests";
import { getServerClient, serverOptions } from "@/lib/ai/server";
import { errorResponse, streamMessage, toTextStreamResponse } from "@/lib/ai/stream";

// Long documents can take a while to analyze; allow up to 5 minutes on Vercel.
export const maxDuration = 300;

/**
 * POST /api/analyze — stream a Markdown analysis (title, summary, key points,
 * action items) of the given content as plain text.
 */
export async function POST(request: Request) {
  const prepared = prepareAnalyze(await request.json().catch(() => null));
  if (!prepared.ok) return prepared.response;

  try {
    const stream = streamMessage(getServerClient(), serverOptions, prepared.request);
    return toTextStreamResponse(stream, request.signal);
  } catch (error) {
    return errorResponse(error);
  }
}
