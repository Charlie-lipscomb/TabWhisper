import { TabWhisperApp } from "@/components/tabwhisper-app";

export default function Home() {
  return <TabWhisperApp />;
}
