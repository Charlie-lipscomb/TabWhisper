# TabWhisper

**Read less. Understand more.**

TabWhisper is a minimal, focused AI research tool. Paste any URL or text — an article, a blog post, documentation, meeting notes — and Claude instantly gives you:

- a **clear summary**
- **key points** as scannable bullets
- **action items** (tasks, decisions, next steps) when there are any
- **answers to your follow-up questions** about the content

Everything streams in as it's written, so you start reading in a second or two, not after the whole response is done.

| Light | Dark |
| --- | --- |
| ![TabWhisper in light mode](docs/screenshot-light.png) | ![TabWhisper in dark mode](docs/screenshot-dark.png) |

---

**Two ways to run it:**

- **On a server (Vercel or any Node host)** — your API key stays secret on the server in an environment variable. Visitors don't need a key.
- **As a static website (GitHub Pages)** — no server at all. Each visitor enters their own Anthropic API key, which is saved only in their browser and sent only to Anthropic.

## Features

- **Paste anything.** A large, distraction-free input that handles long articles and docs (up to ~400K characters).
- **Load from URL.** Fetches a page server-side and extracts the main content with [Mozilla Readability](https://github.com/mozilla/readability) — the engine behind Firefox Reader View. Paste a bare URL and hit **Analyze** to load and analyze in one step.
- **Streaming analysis.** One streamed response is split live into **Summary / Key Points / Action Items** tabs.
- **Q&A.** Ask follow-up questions grounded in the content, with streaming answers and conversation context. The source document is prompt-cached, so follow-ups are faster and cheaper.
- **Copy buttons** on every section, plus **Copy all** as Markdown.
- **Recent analyses** saved in your browser's `localStorage` (nothing is stored on a server).
- **Dark / light mode** that follows your system by default.
- **Responsive** layout that works well on phones.
- **Careful error handling:** friendly messages for missing/invalid API keys, rate limits, unreachable pages, oversized input, and mid-stream failures; a **Stop** button cancels generation (and stops billing for it).
- **Safe URL fetching:** blocks localhost/private-network addresses (re-checked on every redirect), with timeouts and size limits.

## Tech stack

- [Next.js 16](https://nextjs.org) (App Router) + TypeScript
- [Tailwind CSS v4](https://tailwindcss.com) + [shadcn/ui](https://ui.shadcn.com) components
- [Anthropic TypeScript SDK](https://github.com/anthropics/anthropic-sdk-typescript) — Claude Opus 5.5 by default
- `react-markdown` + `remark-gfm` for rendering, `next-themes` for theming, `sonner` for toasts

## Run locally

**Prerequisites:** Node.js 20.9 or newer and an [Anthropic API key](https://platform.claude.com/settings/keys).

```bash
git clone https://github.com/charlie-lipscomb/tabwhisper.git
cd tabwhisper
npm install
cp .env.example .env.local   # then add your API key (see below)
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

Other scripts:

| Command | What it does |
| --- | --- |
| `npm run build` | Production build (server mode) |
| `npm run build:static` | Static site in `out/` (GitHub Pages mode) |
| `npm start` | Serve the production build |
| `npm run lint` | ESLint |
| `npm run typecheck` | TypeScript type check |

## Adding your Anthropic API key

1. Create a key in the [Claude Console](https://platform.claude.com/settings/keys).
2. Put it in `.env.local` at the project root:

   ```bash
   ANTHROPIC_API_KEY=sk-ant-...
   ```

3. Restart `npm run dev`.

This applies to server mode. (In the GitHub Pages / static build, there's no server: click the ⚙︎ **Settings** button in the app and paste your key there instead.)

The key is only read on the server (in `src/lib/anthropic.ts`, which is marked `server-only`) and is never sent to the browser. `.env.local` is git-ignored.

### Optional settings

| Variable | Default | Description |
| --- | --- | --- |
| `ANTHROPIC_MODEL` | `claude-opus-5-5` | Claude model ID to use. |
| `ANTHROPIC_EFFORT` | `medium` | Reasoning effort: `low`, `medium`, `high`, `xhigh`, or `max`. Lower is faster and cheaper; higher is more thorough. |
| `ANTHROPIC_FALLBACKS` | on | If Claude's safety classifiers decline a request, the API automatically retries it on Anthropic's recommended fallback model. Set to `off` only if you route requests through a proxy that doesn't support this. |

## Deploying to GitHub Pages

The repo includes a workflow (`.github/workflows/deploy-pages.yml`) that builds a static version of the app and publishes it to GitHub Pages on every push to `main`.

1. Push the code to the `main` branch on GitHub.
2. In the repository, open **Settings → Pages** and set **Source** to **GitHub Actions**.
3. Push to `main` again, or run the workflow manually from the **Actions** tab (**Deploy to GitHub Pages → Run workflow**).
4. When it finishes, the site is live at `https://<your-username>.github.io/<repo-name>/` (the link is shown in the workflow run).

How the static version differs from server mode:

- **Bring your own key.** There's nowhere to keep a secret on a static site, so the workflow uses no API key. Each visitor clicks **Add your Anthropic API key** (or the ⚙︎ Settings button) and enters their own. It's stored in that browser's `localStorage` and sent directly from the browser to `api.anthropic.com` — never to GitHub. **Never put your own API key in the repository or the build** — it would be visible to everyone.
- **Load from URL uses Claude's web fetch tool.** Browsers can't download other websites directly, so the app asks Claude to fetch the page. This uses some API tokens, and [web fetch](https://platform.claude.com/docs/en/agents-and-tools/tool-use/web-fetch-tool) must be allowed for your organization in the Claude Console. Pasting text always works.
- Model and effort are chosen in the Settings dialog instead of environment variables.
- Free GitHub accounts can publish Pages only from **public** repositories; private repositories need a paid plan.

To try the static build locally:

```bash
npm run build:static
npx serve out
```

## Deploying to Vercel

1. Push the repo to GitHub.
2. In [Vercel](https://vercel.com/new), **Import** the repository. The Next.js preset is detected automatically — no build settings to change.
3. Under **Environment Variables**, add `ANTHROPIC_API_KEY` (and any optional settings above).
4. Click **Deploy**.

Notes:

- The AI routes set `maxDuration = 300` seconds so long documents have time to finish. Vercel plans with Fluid Compute support this; if your plan has a lower cap, Vercel will use that limit instead.
- Responses stream as plain text, which works out of the box on Vercel's Node.js runtime.
- The app has no database — history lives in each visitor's browser.
- **Anyone who can reach your deployment can spend your API credits.** For a public deployment, consider adding authentication (e.g. Vercel Password Protection, or an auth library) and rate limiting.

TabWhisper's server mode also runs anywhere Node.js does (`npm run build && npm start`), including Docker, Railway, Render, or Fly.io.

## How it works

In **server mode**:

```
Browser                                Next.js server                    Anthropic API
───────                                ──────────────                    ─────────────
"Load from URL" ──► POST /api/extract ─► fetch page → Readability ──┐
                    ◄── { title, content } ◄────────────────────────┘

"Analyze"       ──► POST /api/analyze ─► messages.stream() ──────────►  Claude
                    ◄── streamed Markdown text ◄─────────────────────◄
                    (split live into tabs by heading)

Q&A question    ──► POST /api/ask ─────► messages.stream()  ─────────►  Claude
                    (document + prior turns)  (document is prompt-cached)
                    ◄── streamed answer ◄────────────────────────────◄
```

In **static mode** (GitHub Pages), the browser makes the same Claude requests directly with the visitor's key (`src/lib/ai/browser.ts`), and "Load from URL" asks Claude to fetch the page with its web fetch tool. `src/lib/api.ts` picks the mode, and both return the same streamed response, so the UI is identical.

The analysis prompt asks Claude for fixed Markdown headings (`## Title`, `## Summary`, `## Key Points`, `## Action Items`). The client parses the stream as it arrives (`src/lib/sections.ts`), so each tab fills in live from a single request.

## Project structure

```
.github/workflows/
└── deploy-pages.yml           # Builds the static site and deploys to GitHub Pages
src/
├── app/
│   ├── api/
│   │   ├── analyze/route.ts   # Streams the summary / key points / action items
│   │   ├── ask/route.ts       # Streams answers to follow-up questions
│   │   └── extract/route.ts   # Fetches a URL and extracts readable content
│   ├── globals.css            # Theme tokens (light/dark) and Markdown styles
│   ├── layout.tsx             # Fonts, theme provider, toaster
│   └── page.tsx
├── components/
│   ├── tabwhisper-app.tsx     # Top-level client component (state & flows)
│   ├── source-input.tsx       # Paste area + Load from URL / Analyze
│   ├── results-view.tsx       # Title, tabs, and section cards
│   ├── qa-panel.tsx           # Follow-up questions
│   ├── settings-dialog.tsx    # API key / model settings (static mode)
│   ├── history-list.tsx       # Recent analyses
│   ├── markdown.tsx, copy-button.tsx, theme-*.tsx
│   └── ui/                    # shadcn/ui components
├── hooks/
│   └── use-text-stream.ts     # Fetch + read a streaming text response
└── lib/
    ├── api.ts                 # Chooses server routes or direct browser calls
    ├── ai/
    │   ├── prompts.ts         # System prompts and message builders
    │   ├── requests.ts        # Input validation shared by both modes
    │   ├── stream.ts          # Claude streaming, errors, SDK stream → text Response
    │   ├── server.ts          # Server client + env config (server-only)
    │   └── browser.ts         # Bring-your-own-key client + web-fetch URL loading
    ├── extract.ts             # URL fetching, SSRF guard, Readability (server-only)
    ├── sections.ts            # Parses streamed Markdown into sections
    ├── history.ts             # localStorage persistence
    └── constants.ts           # Values shared by client and server
```

## Limitations

- Pages that render their content with client-side JavaScript, or sit behind a login or paywall, can't be extracted — paste the text instead.
- Input is capped at 400,000 characters (roughly 100K tokens). Longer input is rejected with a clear message rather than silently truncated.

## License

MIT
