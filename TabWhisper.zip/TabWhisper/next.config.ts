import type { NextConfig } from "next";

/**
 * Two build targets:
 *
 * - `npm run build` — a normal Next.js server build (Vercel, Node hosts). The
 *   API key lives in `ANTHROPIC_API_KEY` on the server.
 * - `npm run build:static` (`STATIC_EXPORT=true`) — a fully static site in
 *   `out/` for GitHub Pages or any static host. There is no server, so the
 *   API routes are left out and visitors use their own API key in the browser.
 */
const isStatic = process.env.STATIC_EXPORT === "true";

// GitHub Pages serves project sites from a sub-path, e.g. /TabWhisper.
const basePath = process.env.NEXT_PUBLIC_BASE_PATH?.replace(/\/$/, "") || undefined;

const nextConfig: NextConfig = {
  // Partial prerendering features need a server, so they're off for static exports.
  cacheComponents: !isStatic,
  partialPrefetching: !isStatic,
  turbopack: {
    rules: {
      "*.css": {
        loaders: ["@tailwindcss/turbopack"],
        as: "*.css",
      },
    },
  },
  env: {
    NEXT_PUBLIC_STATIC_EXPORT: String(isStatic),
  },
  ...(isStatic && {
    output: "export",
    basePath,
    // Route handlers (`route.ts`) can't run on a static host — only pick up
    // `.tsx` files (pages and layouts) so `src/app/api/**` is excluded.
    pageExtensions: ["tsx"],
    images: { unoptimized: true },
  }),
};

export default nextConfig;
